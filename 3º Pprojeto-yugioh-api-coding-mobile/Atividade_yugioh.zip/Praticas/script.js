async function getCard() {

    try {

        let response = await fetch("https://db.ygoprodeck.com/api/v7/randomcard.php")
        let data = await response.json()

        console.log(data)

        document.getElementById("Carta").innerHTML = `
            <h2>${data.name}</h2>

            <img src="${data.card_images[0].image_url}" width="250">

            <p><b>Tipo:</b> ${data.type}</p>
            <p><b>Atributo:</b> ${data.attribute || "N/A"}</p>
            <p><b>Nível:</b> ${data.level || "N/A"}</p>

            <p><b>ATK:</b> ${data.atk || "?"} | <b>DEF:</b> ${data.def || "?"}</p>

            <p><b>Descrição:</b> ${data.desc}</p>
        `

    } catch (error) {
        console.log("Erro:", error)
    }

}